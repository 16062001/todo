package com.example.to_do_list

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
